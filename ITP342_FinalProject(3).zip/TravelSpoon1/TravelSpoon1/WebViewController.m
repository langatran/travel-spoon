//
//  WebViewController.m
//  TravelSpoon1
//
//  Created by langa tran on 12/8/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import "WebViewController.h"
#import "SuggestionsViewController.h"

@interface WebViewController ()
@property RecommendationModel *webRec;

@end

@implementation WebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //set the delegate
    self.webView.delegate = self;
    
    _webRec = [RecommendationModel shared];

    //create a request and then load the request onto the  webview
    NSURLRequest * requestUrl = [NSURLRequest requestWithURL:_urlToPass];
    [self.webView loadRequest:requestUrl];
  
    
    
    
}

//show the activity indicator while loading
-(void) webViewDidStartLoad:(UIWebView *)webView{
    [self.waitingView startAnimating];
}


// stop showing the activity indicator when finished loading
-(void) webViewDidFinishLoad:(UIWebView *)webView {
     [self.waitingView stopAnimating];
    self.waitingView.hidesWhenStopped  = YES;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
