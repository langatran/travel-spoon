//
//  Search.h
//  TravelSpoon1
//
//  Created by langa tran on 12/1/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Search : NSObject

@end
