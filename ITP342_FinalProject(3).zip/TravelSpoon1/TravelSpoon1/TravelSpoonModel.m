//
//  TravelSpoonModel.m
//  TravelSpoon1
//
//  Created by langa tran on 11/30/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import "TravelSpoonModel.h"

@interface TravelSpoonModel ()

@end

@implementation TravelSpoonModel


//setting up the user - each user has a username and password
- (instancetype) init {
    self = [super init];
    
    if (self) {
    
        _username = nil;
        _password = nil;
        
    }
    
    
    
    
    return self;
}

// create singleton
+ (instancetype) sharedModel{
    static TravelSpoonModel *travelSpoonModel = nil;
    
    // Grand Central Dispatch
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        travelSpoonModel = [[TravelSpoonModel alloc] init];
    });
    
    return travelSpoonModel;
}

//array for users using NSUser defaults
-(NSMutableArray *)users {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    NSMutableArray *result = [[NSMutableArray alloc] init];
    
    
    //add the defaults to the array
    [result addObjectsFromArray:[defaults valueForKey:keyUsers]];
    
    return result;
}


//search the user
-(NSDictionary *) searchUser: (NSString *) username{
    
    // look for the user in the array of users
    for (NSDictionary *loopUser  in self.users ) {
        if ( [[loopUser valueForKey:@"username"] isEqualToString:username] ) {
            return loopUser;
        }

    }
    
    return nil;
    
}

//save new user to the nsuser defaults 
- (void) saveUser:(NSString *) name password: (NSString* ) pass {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    //   [defaults setValue:self.users forKey:keyUsers];
    
    [defaults setObject:name forKey:kusernameKey];
    [defaults setObject:pass forKey:kpasswordKey];
    
    [defaults setBool:YES forKey:@"registered"];
    [defaults synchronize];
    
    
}

//register user
- (BOOL) registerUser:(NSString *) name password: (NSString* ) pass {
    
    if ( [self searchUser:name] != nil ) {
        NSLog(@"User exists: %@", name);
        return NO;
    }
    
    //create a new user if it doesn't exist yet
    NSMutableDictionary *newUser = [NSMutableDictionary new];
    [newUser setValue:name forKey:kusernameKey];
    [newUser setValue: pass forKey:kpasswordKey];
    
    // add the new user to the array of new users
    NSMutableArray *newUsers = [[NSMutableArray alloc] initWithArray:self.users];
    [newUsers addObject:newUser];
    NSLog(@"self.users %@", newUsers);
    
    
    [[NSUserDefaults standardUserDefaults] setValue:newUsers forKey:keyUsers];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    //save the name and password
    [self saveUser:name password:pass];
    return YES;
    
}

- (BOOL) checkUsernameAndPassword: (NSString *) name password: (NSString* ) pass {
    
    self.username = name;
    self.password = pass;

    NSDictionary *user = [self searchUser:self.username];
    
    //if the username matches the password
    if ( user && [[user valueForKey:@"password"] isEqualToString:self.password]){
        
        [self saveUser:self.username password:self.password];
        return YES;
    }
    
    else {
        
        return NO;
//        [self presentViewController: [self showAlert: @"Error" :@"Username or password is incorrect."] animated: YES completion: nil];
        
    }


}

-(NSString *) getUsername {
    return self.username;
}

-(NSString *) getPassword {
    return self.password;
}


//set the users
-(void)setUsers:(NSMutableArray *)users {
    [[NSUserDefaults standardUserDefaults] setValue:users forKey:keyUsers];
}





@end
