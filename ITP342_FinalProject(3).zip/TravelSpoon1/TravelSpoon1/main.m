//
//  main.m
//  TravelSpoon1
//
//  Created by langa tran on 11/29/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
