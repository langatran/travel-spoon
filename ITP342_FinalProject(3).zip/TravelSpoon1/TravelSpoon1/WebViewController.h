//
//  WebViewController.h
//  TravelSpoon1
//
//  Created by langa tran on 12/8/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import <UIKit/UIKit.h>

//this view controller will load the website of the selected restaurant

@interface WebViewController : UIViewController <UIWebViewDelegate>


//properties
@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *waitingView;
@property (strong, nonatomic) NSURL *urlToPass;


@end
