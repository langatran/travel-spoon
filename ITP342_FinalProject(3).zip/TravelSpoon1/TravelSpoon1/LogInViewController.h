//
//  LogInViewController.h
//  TravelSpoon1
//
//  Created by langa tran on 11/30/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import <UIKit/UIKit.h>


//static NSString *keyUsers = @"users";

@interface LogInViewController : UIViewController <UITextFieldDelegate> {
    
}


// actions for log in and registering
- (IBAction)loginButtonDidPressed:(id)sender;

- (IBAction)registerButtonDidPressed:(id)sender;

- (UIAlertController *) showAlert: (NSString *) title : (NSString *) message;



@end
