//
//  RecommendationModel.m
//  TravelSpoon1
//
//  Created by langa tran on 12/1/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import "TravelSpoonModel.h"
#import "RecommendationModel.h"


int radiusFilter;


@interface RecommendationModel()

@property (readonly, strong, nonatomic) NSString * foodType;
@property (readonly, strong, nonatomic) NSString * priceRange;
@property (readonly, strong, nonatomic) NSString * startingZip;


@end

@implementation RecommendationModel


- (instancetype) init {
    self = [super init];
    
    if (self) {
    
        _foodType = nil;
        _priceRange = nil;
       // distanceRange = 0.0;
        _startingZip = nil;
        
        
        //setting the restaurants
        _restaurantTypes = @[@"African", @"American",@"Breakfast", @"Cajun", @"Caribbean",@"Dinner", @"French",@"German", @"Japanese", @"Korean",@"Lebanese", @"Lunch",@"Mediterranean", @"Mexican", @"Spanish",@"Thai",@"Turkish", @"Vegan",@"Vegetarian",@"Vietnamese"];
        
        //setting the distances
        _distances = @[
                       [[NSNumber alloc] initWithFloat:0.5],
                       [[NSNumber alloc] initWithFloat:1.0],
                       [[NSNumber alloc] initWithFloat:5.0],
                       [[NSNumber alloc] initWithFloat:10.0],
                       [[NSNumber alloc] initWithFloat:15.0],
                       [[NSNumber alloc] initWithFloat:20.0] ];
        
        //setting the distance labels
        _distancesLabel = @[@"within .5 miles",@"within 1 mile", @"within 5 miles", @"within 10 miles",@"within 15 miles", @"within 20 miles"];
                             
}
    
    return self;
}


//init with latitude
- (instancetype)initWithLatitude:(double)latitude longitude:(double)longitude{
    _myLatitude = latitude;
    _myLongitude= longitude;
    return self;
    
}

//implmenting singleton
+ (instancetype) shared {
    static RecommendationModel *recommendationModel = nil;
    
    // Grand Central Dispatch
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        recommendationModel = [[RecommendationModel alloc] init];
    });
    
    return recommendationModel;
}




- (NSString *) getFoodType {
    return self.foodType;
}

- (NSString *) getPriceRange
{
    return self.priceRange;
}

- (NSString *) getStartingZip {
    return self.startingZip;
}

- (int) getRadiusFilter{
    return radiusFilter;
}

- (double) getLatitude {
    return _myLatitude;
}
- (double) getLongitude{
    return _myLongitude;
}


/// create a query to find the yelp business given
- (void) search:(void(^)(bool gotResults))searchHandler  {
    
    // create coordinate with USC's location
    YLPCoordinate *newCoordinate = [[YLPCoordinate alloc] initWithLatitude: self.myLatitude  longitude: self.myLongitude];
    
    // create coordinate
    YLPQuery *query = [[YLPQuery alloc] initWithCoordinate: newCoordinate];

    //implement filters using specifications frm user
    NSString * filter = [NSString stringWithFormat:@"%@", self.typeOfFood.lowercaseString ];
    query.categoryFilter = @[filter];
    query.radiusFilter = (NSInteger)(self.dist * kMetersInMile); // convert to miles
    query.limit = 20;
    query.sort = CLLocationDistanceMax;

    NSLog(@"categoryFilter %@", query.categoryFilter);
    
    
    //perform search using the app delegate
    [AppDelegate.sharedClient searchWithQuery: query completionHandler:^(YLPSearch * search, NSError *error) {
        
        self.restaurants = [NSMutableArray new];

        
//        NSLog(@"Error %@", error.localizedDescription);
//        NSLog(@"Results %li", search.businesses.count);
        
    
        //add the search result into the array of restaurants
        for (YLPBusiness * newBusiness in search.businesses) {
            if ( newBusiness.rating >= self.minRating) {
                [self.restaurants addObject: newBusiness];
                  NSLog(@"ACCEPTED %@ rating %f", newBusiness.name, newBusiness.rating);
            } else {
                NSLog(@"REJECTED %@ rating %f", newBusiness.name, newBusiness.rating);
            }
            
        }
        
            dispatch_async(dispatch_get_main_queue(), ^{
            searchHandler(search.businesses.count > 0);
        });
    }];
    
    
     
     return;

}

///return number of restaurants
- (NSUInteger) numberOfRestaurants {
    NSLog(@"%li", self.restaurants.count);
    return (NSUInteger)self.restaurants.count;

    
}

//return the yelp busienss at the index
- (YLPBusiness *) restaurantAtIndex: (NSUInteger) index{
    return self.restaurants[index];
}

@end
