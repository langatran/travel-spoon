//
//  SuggestionsTableViewController.m
//  TravelSpoon1
//
//  Created by langa tran on 12/1/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//


#import "SuggestionsTableViewController.h"
#import "WebViewController.h"


@interface SuggestionsTableViewCell : UITableViewCell

//labels
@property (weak, nonatomic) IBOutlet UILabel *restaurantNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *addressLabel;
@property (weak, nonatomic) IBOutlet UILabel *ratingLabel;
@property (weak, nonatomic) IBOutlet UIImageView *restaurantImageView;


@end

@implementation SuggestionsTableViewCell

@end

@interface SuggestionsTableViewController ()

@property (strong, nonatomic) IBOutlet UITableView *suggestionsTableView;
@property (strong, nonatomic) TravelSpoonModel * searchModel;
@property(strong,nonatomic) RecommendationModel * r1;

@end

@implementation SuggestionsTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // _suggestionsTableView.contentInset = UIEdgeInsetsMake(60, 0, 0, 0);
    
    _suggestionsTableView.delegate = self;
    _suggestionsTableView.dataSource = self;
    _r1 = [RecommendationModel shared];
    
    [self.tableView reloadData];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

//--------------- data source methods ---------------------//

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    ///restaurants count
    return [self.r1 numberOfRestaurants];
//
}

- (UITableViewCell *) tableView: (UITableView *) tableView cellForRowAtIndexPath:(NSIndexPath *) indexPath {
    
    NSLog(@"Cell for %li  count %li", indexPath.row, [self.r1 numberOfRestaurants]);
    // configure cell
    SuggestionsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SuggestionsCell" forIndexPath:indexPath];
    
    // Grab business
    YLPBusiness *business= [[RecommendationModel shared] restaurantAtIndex: indexPath.row];
    NSString * restaurantName = [NSString stringWithFormat:@"%@",business.name];
    NSMutableString *restaurantAddress = [[NSMutableString alloc] initWithString:@""];
    
    
    //print out the addres and state and zipcode in the tableview cell
        for ( NSString *line in business.location.address ) {
        
            //create array of keywords that cause a redundant address to appear in tableview cell
            NSArray *keyWords = @[@"unit", @"inside", @"ste", @"lobby", @"kiosk", @"grand central market",@"la reyna",@"usc"];
            bool foundKeyword = NO;
            
            //don't reiterate the adddress
            for ( NSString *keyWord in keyWords ) {
                if ( [line.lowercaseString containsString:keyWord] ) {
                    [restaurantAddress appendFormat:@" "];
                    foundKeyword = YES;
                    break;
                }
            }
            
            
            //if the keyword is not found, print the city, state, and zipcode below the address
            if ( foundKeyword == NO )   {
                [restaurantAddress appendFormat:@"%@%@", line,@","];
                [restaurantAddress appendFormat:@"\n%@%@ %@ %@", business.location.city, @",", business.location.stateCode, business.location.postalCode];
            }
        
            
        }

    double restaurantRating =  business.rating;
    
    // set the labels
    cell.restaurantNameLabel.lineBreakMode = NSLineBreakByWordWrapping; // allow text wrap
    cell.restaurantNameLabel.numberOfLines = 0;
    cell.restaurantNameLabel.text = restaurantName;
    
    cell.addressLabel.text = restaurantAddress;
    cell.ratingLabel.text = [NSString stringWithFormat: @"%0.1f", restaurantRating];
    
    
    //show image of the restaurant as given by yelp
    NSData *imageData = [[NSData alloc] initWithContentsOfURL: business.imageURL];
    
    [cell.restaurantImageView setImage:[UIImage imageWithData: imageData]];
    
    return cell;
    
}




#pragma mark - Navigation


//segue into the webview
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
  
    
    // webview controller is the destination controller
    WebViewController *webView = segue.destinationViewController;
    
    NSInteger index = self.suggestionsTableView.indexPathForSelectedRow.item;
    
    //restaurant for index
    YLPBusiness *resto = [[RecommendationModel shared] restaurantAtIndex: index];
    
    
    //pass the url of the requested restaurant to the webview
    webView.urlToPass = resto.URL;
    
    
}






@end
