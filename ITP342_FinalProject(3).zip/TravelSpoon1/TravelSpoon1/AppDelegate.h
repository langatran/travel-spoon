//
//  AppDelegate.h
//  TravelSpoon1
//
//  Created by langa tran on 11/29/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <YelpAPI/YelpAPI.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

+ (YLPClient *) sharedClient;


@end

