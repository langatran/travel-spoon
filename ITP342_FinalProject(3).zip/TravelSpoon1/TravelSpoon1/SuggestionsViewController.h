//
//  SuggestionsViewController.h
//  TravelSpoon1
//
//  Created by langa tran on 11/29/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecommendationModel.h"
#import "TravelSpoonModel.h"
#import "LogInViewController.h"
#import <CoreLocation/CoreLocation.h>


@interface SuggestionsViewController : UIViewController <UIPickerViewDelegate>


@property (strong, nonatomic) NSString *latitude;


@end

