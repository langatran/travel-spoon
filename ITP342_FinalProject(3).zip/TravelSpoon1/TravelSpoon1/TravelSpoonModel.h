//
//  TravelSpoonModel.h
//  TravelSpoon1
//
//  Created by langa tran on 11/30/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import <Foundation/Foundation.h>


//this model is going to hold the info regarding the users

static NSString * const kusernameKey = @"username";
static NSString * const kpasswordKey = @"password";
static NSString * const cancelButtonTitle = @"OK";

static NSString *keyUsers = @"users";

//NSUserDefaults *defaults;

@interface TravelSpoonModel : NSObject

//username properties
@property (strong, nonatomic) NSString *username;
@property (strong, nonatomic) NSString *password;

//array to hold the users
@property (readwrite, assign) NSMutableArray *users;

//methods to implement 
+ (instancetype) sharedModel;
-(void)setUsers:(NSMutableArray *)users;
-(NSDictionary *) searchUser: (NSString *) username;
-(void) saveUser:(NSString *) name password: (NSString* ) pass;
- (BOOL) registerUser:(NSString *) name password: (NSString* ) pass;
-(BOOL) checkUsernameAndPassword: (NSString *) name password: (NSString* ) pass;


@end

