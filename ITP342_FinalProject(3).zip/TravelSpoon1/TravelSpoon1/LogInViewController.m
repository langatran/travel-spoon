//
//  LogInViewController.m
//  TravelSpoon1
//
//  Created by langa tran on 11/30/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import "TravelSpoonModel.h"
#import "LogInViewController.h"
#import "SuggestionsViewController.h"


@interface LogInViewController ()
@property (weak, nonatomic) IBOutlet UITextField *usernameTextField;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;
@property (weak, nonatomic) IBOutlet UIButton * logInButton;
@property (weak, nonatomic) IBOutlet UIButton * registerButton;
@property (strong, nonatomic) NSString *userInput;
@property (strong, nonatomic) NSString *passInput;

//create an array of ns object 


@property(strong,nonatomic) TravelSpoonModel * t1;

// @property(strong, nonatomic) NSMutableArray * users;


@end

@implementation LogInViewController


-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    self.usernameTextField.text = nil;
    self.passwordTextField.text = nil;
    
    

    NSString *username = [[NSUserDefaults standardUserDefaults] valueForKey:kusernameKey];
    
    _t1 = [TravelSpoonModel sharedModel];
    
    //if the username is a user
    if ( username ) {
        NSDictionary *user = [_t1 searchUser:username];
        
        //set the username and password to the appropriate keys
        if ( user ) {
            NSString *pass = [[NSUserDefaults standardUserDefaults] valueForKey:kpasswordKey];
            if ( [pass isEqualToString:[user valueForKey:kpasswordKey]]) {
                self.usernameTextField.text = username;
                self.passwordTextField.text = pass;
                
            }
        }
    }
    

}

// log out is removing teh two keys //

- (void)viewDidLoad {
    [super viewDidLoad];

    NSLog(@"users: ");
    NSLog(@"%@", self.t1.users);

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    

}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    //[self.usernameTextField resignFirstResponder];
    [self.passwordTextField resignFirstResponder];
    return YES;
}

//ocurs when log in button is pressed
- (IBAction)loginButtonDidPressed:(id)sender {
    
    //if there is text in the fields
    if (self.usernameTextField.text.length > 0 && self.passwordTextField.text.length > 0){
        
        //check the username and password
        if ([self.t1 checkUsernameAndPassword:self.usernameTextField.text password:self.passwordTextField.text]) {
            [self performSegueWithIdentifier: @"login" sender: self];
        }
        else {
        //incorrect username and password
              [self presentViewController: [self showAlert: @"Error" :@"Username or password is incorrect."] animated: YES completion: nil];
        }
    }
    
    //no text in fields
        else {
            [self presentViewController: [self showAlert: @"Error" :@"Please enter all fields to log in."] animated: YES completion: nil];
            
        }
    
}


//occurs when register button is pressed
- (IBAction)registerButtonDidPressed:(id)sender{
    
    //if text fields are empty
    if ([self.usernameTextField.text isEqualToString:@""] || [self.passwordTextField.text isEqualToString:@""]) {
        
        [self presentViewController: [self showAlert: @"Error" :@"Please enter all fields to register."] animated: YES completion: nil];
        
    }
    
    
    else {
        self.userInput = self.usernameTextField.text;
        self.passInput = self.passwordTextField.text;
        
        //check if user is already registered
        if ([self.t1 registerUser: self.userInput password: self.passInput] == NO){
        [self presentViewController: [self showAlert: @"Error" :@"User is already registered."] animated: YES completion: nil];
        }
        else {
            
            //register user
            [self.t1 registerUser: self.userInput password: self.passInput];
            [self performSegueWithIdentifier: @"login" sender: self];
        }
       
        
    }
    
}

//default alert code
-(UIAlertController *) showAlert : (NSString *) title : (NSString *) message {
   

    UIAlertController * alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle: UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction *action)
                               {
                                   NSLog(@"Ok action");}];
    
    
    UIAlertAction *cancelAction =  [UIAlertAction actionWithTitle:@"Cancel"
                                                            style:UIAlertActionStyleCancel
                                                          handler:^(UIAlertAction *action)
                                    {
                                        NSLog(@"Cancel action");
                                    }];
    

    [alert addAction: okAction];
    [alert addAction: cancelAction];
    

    return alert;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/





@end
