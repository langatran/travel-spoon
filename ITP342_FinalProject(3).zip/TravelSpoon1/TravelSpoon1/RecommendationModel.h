//
//  RecommendationModel.h
//  TravelSpoon1
//
//  Created by langa tran on 12/1/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import "AppDelegate.h"
#import <Foundation/Foundation.h>
#import <YelpAPI/YelpAPI.h>
#import <CoreLocation/CoreLocation.h>

//this model is to create suggestions using the Yelp API

static double kMetersInMile= 1609.34;

@interface RecommendationModel : NSObject


//arrays to hold the different data
@property (strong, nonatomic) NSArray *restaurantTypes;
@property(strong, nonatomic) NSArray *suggestedRestaurants;
@property (strong, nonatomic) NSArray *distances;
@property (strong, nonatomic) NSArray *distancesLabel;


// properties to hold data
@property (nonatomic) double dist;
@property (nonatomic) double myLatitude;
@property (nonatomic) double myLongitude;
@property (nonatomic) double minRating;


@property (strong, nonatomic) NSString * price;
@property (strong, nonatomic) NSString * typeOfFood;

@property(strong, nonatomic) NSMutableArray *restaurants;
@property (strong, nonatomic) YLPBusiness *business;


//shared model

//- (instancetype)initWithLocation:(NSString *)location;
+ (instancetype) shared;

//getting latitude and longitutde
- (instancetype)initWithLatitude:(double)latitude longitude:(double)longitude;
- (double) getLatitude;
- (double) getLongitude;

- (NSUInteger) numberOfRestaurants;
- (NSString *) getFoodType;
- (NSString *) getPriceRange;
- (NSString *) getStartingZip;


- (int) getRadiusFilter;


//completion handler
- (void) search:(void(^)(bool gotResults))completionHandler;
- (YLPBusiness *) restaurantAtIndex: (NSUInteger) index;





@end
