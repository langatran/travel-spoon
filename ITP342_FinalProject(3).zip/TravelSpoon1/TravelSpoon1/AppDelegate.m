//
//  AppDelegate.m
//  TravelSpoon1
//
//  Created by langa tran on 11/29/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import "AppDelegate.h"


@interface AppDelegate ()
@property(strong,nonatomic)YLPClient *client;
@end

@implementation AppDelegate


+ (YLPClient *)sharedClient {
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    return appDelegate.client;
}

#pragma mark UIApplicationDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    

    
    
    [YLPClient authorizeWithAppId:@"xRQ1lwdu5cLB8cEf7nXrBw" secret:@"jb5eT6KdaiGLU9FYNP26KyFBz0GYUsdDmnRL91SemHGYjlv26bJUEW3c0EHQNkMW" completionHandler:^(YLPClient *client, NSError *error) {
        self.client = client;
        
        if (!client) {
            NSLog(@"Authentication failed: %@", error);
        }
    }];
    
    return YES;
}

@end
